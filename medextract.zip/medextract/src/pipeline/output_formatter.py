"""Unified output formatting and export for MedExtract-AI results.

Provides functions for every supported export format (JSON, CSV, FHIR)
as well as single-document helpers.  :class:`~src.pipeline.core_engine.MedExtractEngine`
delegates all disk I/O through this module.

Usage
-----
    from src.pipeline.output_formatter import export_results

    path = export_results(results, output_dir="output", fmt="json")
"""
from __future__ import annotations

import csv
import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

from pydantic import BaseModel

from src.pipeline.validation import (
    ClinicalHistorySchema,
    Prescription,
    ResultSchema,
    SCHEMA_REGISTRY,
    validate_batch,
)

logger = logging.getLogger(__name__)

# ── Type alias ───────────────────────────────────────────────────

FormattedDoc = Union[ResultSchema, Prescription, ClinicalHistorySchema]

_SCHEMA_MAP = SCHEMA_REGISTRY  # single source of truth


# ── Single-document helpers ──────────────────────────────────────

def format_document(doc: FormattedDoc) -> dict:
    """Convert a validated Pydantic document into a plain dict.

    Parameters
    ----------
    doc : FormattedDoc
        A validated schema instance.

    Returns
    -------
    dict
        The document with ``None`` values excluded.
    """
    return doc.model_dump(exclude_none=True)


def save_json_output(doc: FormattedDoc, output_path: str) -> str:
    """Serialise a single validated document to a JSON file.

    Parameters
    ----------
    doc : FormattedDoc
        A validated schema instance.
    output_path : str
        Destination file path (parent directories created automatically).

    Returns
    -------
    str
        The absolute path of the written file.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    formatted = format_document(doc)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(formatted, f, indent=2, ensure_ascii=False)
    logger.debug("Wrote single JSON to %s", output_path)
    return os.path.abspath(output_path)


# ── Batch export – JSON ──────────────────────────────────────────

def _write_json_item(item: Dict[str, Any], json_dir: Path) -> str:
    """Write a single result dict as a JSON file. Thread-safe."""
    safe_name = Path(item["file"]).stem
    doc_path = json_dir / f"{safe_name}.json"
    with open(doc_path, "w", encoding="utf-8") as f:
        json.dump(item, f, indent=2, ensure_ascii=False)
    return str(doc_path)


def export_json(
    items: List[Dict[str, Any]],
    output_dir: str,
    *,
    dirname: str | None = None,
    max_workers: int | None = None,
) -> str:
    """Export each result dict as a separate JSON file.

    Parameters
    ----------
    items : list[dict]
        Document result dicts (from :class:`DocumentResult.as_dict`).
    output_dir : str
        Parent directory.
    dirname : str, optional
        Name of the sub-directory for the JSON files.  Defaults to
        ``medextract_results``.
    max_workers : int, optional
        Thread-pool size for parallel writes.  ``None`` lets the executor
        decide.  Pass ``1`` to force sequential writes.

    Returns
    -------
    str
        Path to the output sub-directory.
    """
    json_dir = Path(output_dir) / (dirname or "medextract_results")
    json_dir.mkdir(parents=True, exist_ok=True)

    if not items:
        logger.info("No items to export as JSON.")
        return str(json_dir)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_write_json_item, item, json_dir): item
            for item in items
        }
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as exc:
                item = futures[future]
                logger.warning("JSON write failed for %s: %s", item.get("file"), exc)

    logger.info("Exported %d JSON files to %s", len(items), json_dir)
    return str(json_dir)


# ── Batch export – CSV ───────────────────────────────────────────

def export_csv(
    items: List[Dict[str, Any]],
    output_dir: str,
    *,
    filename: str | None = None,
) -> str:
    """Export results as a single CSV table.

    Nested ``extracted_data`` dicts are JSON-serialised into the cell so
    that the CSV remains flat.

    Parameters
    ----------
    items : list[dict]
        Document result dicts.
    output_dir : str
        Parent directory.
    filename : str, optional
        CSV filename.  Defaults to ``medextract_results.csv``.

    Returns
    -------
    str
        Path to the written CSV file.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / (filename or "medextract_results.csv")

    if not items:
        csv_path.write_text("")
        return str(csv_path)

    # Collect all keys across items (some may have _validation_error).
    seen: dict = {}
    for item in items:
        for k in item:
            if k not in seen:
                seen[k] = None
    fieldnames = list(seen)

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in items:
            flat = dict(row)
            if isinstance(flat.get("extracted_data"), dict):
                flat["extracted_data"] = json.dumps(
                    flat["extracted_data"], ensure_ascii=False
                )
            writer.writerow(flat)

    logger.info("Exported %d results to %s", len(items), csv_path)
    return str(csv_path)


# ── Batch export – FHIR ─────────────────────────────────────────

def _process_fhir_item(
    item: Dict[str, Any],
    fhir_dir: Path,
) -> Optional[dict]:
    """Validate, map to FHIR, and write a single item. Thread-safe.

    Returns the FHIR resource dict on success, or ``None`` on failure.
    """
    from src.pipeline.fhir_mapper import map_to_fhir_loose

    doc_type = item.get("document_type")
    data = item.get("extracted_data")
    if not doc_type or not data or doc_type not in _SCHEMA_MAP:
        return None

    try:
        model_cls = _SCHEMA_MAP[doc_type]
        model = model_cls(**data)
        fhir_resource = map_to_fhir_loose(model)

        safe_name = Path(item["file"]).stem
        fhir_path = fhir_dir / f"{safe_name}_fhir.json"
        with open(fhir_path, "w", encoding="utf-8") as f:
            json.dump(fhir_resource, f, indent=2, ensure_ascii=False)

        return fhir_resource
    except Exception as exc:
        logger.warning("FHIR export skipped for %s: %s", item.get("file"), exc)
        return None


def export_fhir(
    items: List[Dict[str, Any]],
    output_dir: str,
    *,
    dirname: str | None = None,
    bundle: bool = True,
    max_workers: int | None = None,
) -> str:
    """Export results as FHIR-mapped JSON resources.

    Each document whose type is recognised and whose ``extracted_data``
    can be validated is converted to a loose FHIR resource and saved as
    a ``<stem>_fhir.json`` file.  When *bundle* is ``True`` (default),
    a ``bundle.json`` containing all successfully-mapped resources is
    also written.

    Parameters
    ----------
    items : list[dict]
        Document result dicts.
    output_dir : str
        Parent directory.
    dirname : str, optional
        Sub-directory name.  Defaults to ``medextract_fhir``.
    bundle : bool
        When ``True`` (default), also write a FHIR Bundle that wraps
        every individual resource.
    max_workers : int, optional
        Thread-pool size for parallel FHIR mapping and writes.

    Returns
    -------
    str
        Path to the output sub-directory.
    """
    from src.pipeline.fhir_mapper import build_fhir_bundle

    fhir_dir = Path(output_dir) / (dirname or "medextract_fhir")
    fhir_dir.mkdir(parents=True, exist_ok=True)

    all_resources: List[dict] = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_process_fhir_item, item, fhir_dir): item
            for item in items
        }
        for future in as_completed(futures):
            try:
                resource = future.result()
                if resource is not None:
                    all_resources.append(resource)
            except Exception as exc:
                item = futures[future]
                logger.warning(
                    "FHIR worker failed for %s: %s", item.get("file"), exc
                )

    exported = len(all_resources)

    # Write combined FHIR Bundle
    if bundle and all_resources:
        bundle_data = build_fhir_bundle(all_resources)
        bundle_path = fhir_dir / "bundle.json"
        with open(bundle_path, "w", encoding="utf-8") as f:
            json.dump(bundle_data, f, indent=2, ensure_ascii=False)
        logger.info("FHIR Bundle (%d entries) → %s", exported, bundle_path)

    logger.info("Exported %d FHIR resource(s) to %s", exported, fhir_dir)
    return str(fhir_dir)


# ── Unified dispatcher ───────────────────────────────────────────

def export_results(
    results: Sequence[Dict[str, Any]],
    *,
    output_dir: str,
    fmt: str = "json",
    filename: str | None = None,
    validate: bool = True,
    strict: bool = False,
    max_workers: int | None = None,
) -> str:
    """Persist results to disk in the requested format.

    Parameters
    ----------
    results : sequence of dict
        The results to export.
    output_dir : str
        Directory to write output into (created if missing).
    fmt : str
        ``"json"`` | ``"csv"`` | ``"fhir"``.
    filename : str, optional
        Override the output filename or sub-directory name.
    validate : bool
        When ``True`` (default), each item with ``extracted_data`` is
        re-validated against its schema before export.  Items that fail
        gain a ``_validation_error`` key (or are dropped when *strict*).
    strict : bool
        When ``True`` **and** *validate* is ``True``, items that fail
        schema re-validation are excluded from the export entirely.
    max_workers : int, optional
        Thread-pool size for parallel file writes (JSON, FHIR).
        ``None`` lets the executor choose a sensible default.

    Returns
    -------
    str
        Path to the output file or directory.

    Raises
    ------
    ValueError
        If *fmt* is not one of the supported formats.
    """
    items = list(results)

    if validate:
        items = validate_batch(items, strict=strict)

    if fmt == "json":
        return export_json(items, output_dir, dirname=filename, max_workers=max_workers)
    elif fmt == "csv":
        return export_csv(items, output_dir, filename=filename)
    elif fmt == "fhir":
        # Read FHIR settings from config when available
        try:
            from src.config import settings as _settings
            fhir_bundle = _settings.fhir_bundle
            fhir_dirname = filename or _settings.fhir_output_dir
        except Exception:
            fhir_bundle = True
            fhir_dirname = filename
        return export_fhir(
            items, output_dir, dirname=fhir_dirname, bundle=fhir_bundle,
            max_workers=max_workers,
        )
    else:
        from src.pipeline.exceptions import ExportError
        raise ExportError(
            fmt, f"Unsupported format {fmt!r}. Use 'json', 'csv', or 'fhir'."
        )


__all__ = [
    "FormattedDoc",
    "export_csv",
    "export_fhir",
    "export_json",
    "export_results",
    "format_document",
    "save_json_output",
]
